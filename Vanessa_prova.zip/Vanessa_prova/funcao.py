'''
Crie uma função chamada "entrada". Essa função deve receber um
parâmetro de entrada. A função deve imprimir o parâmetro de entrada e
retornar o valor digitado pelo usuário. No arquivo principal, chame a
função "entrada" e imprima o valor retornado por ela.
'''

def entrada():
entrada = input("Digite: ")
return entrada
