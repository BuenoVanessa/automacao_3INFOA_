from funcoes import entrada
print("A entrada digitada é:", entrada)
